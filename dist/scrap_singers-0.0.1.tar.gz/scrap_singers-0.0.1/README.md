# Scraping_singers_lyrics
***
Scraping singers lyrics using spacy and genius ID

# I still need to write the doc 😭